module TypeRoomsHelper
end
