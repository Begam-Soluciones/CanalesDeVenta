module SolicitudsHelper
end
