module HotelRoomsHelper
end
