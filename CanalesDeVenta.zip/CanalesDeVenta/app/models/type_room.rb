class TypeRoom < ActiveRecord::Base
	has_many :hotel_rooms
end
