class Disponibilidad < ActiveRecord::Base
end
