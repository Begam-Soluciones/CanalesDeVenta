class HotelRoom < ActiveRecord::Base
  belongs_to :type_room
  belongs_to :disponibilidad
  has_many :rooms
end
