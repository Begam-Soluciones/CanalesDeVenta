class Room < ActiveRecord::Base
	belongs_to :reserva
	belongs_to :hotel_room
end
