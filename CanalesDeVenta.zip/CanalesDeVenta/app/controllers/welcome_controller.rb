class WelcomeController < ApplicationController
  # GET /welcome
  # require 'C:\canalesDeVenta\wired'
  require './wired'
  require 'date'
  def index
    # user = User.find_by(subdomain: request.subdomains)
    # wired = Wired.new(user.account_code_ch, user.password_ch, user.provider_key_ch, user.lcode_ch)
    # wired.aquire_token
    # ancillary= 1
    # mark= 0
        
    # @response = wired.fetch_new_bookings(ancillary, mark)

  # type_rooms  = TypeRoom.find_by(id_room: 142495)
  # hotel_rooms_t = type_rooms.hotel_rooms
  # hotel_rooms = Array.new
  # hotel_rooms_t.each { |e| 
  #  hotel_rooms << e.nro_habitacion
  # }
  # @rooms = Room.where('rooms.reserva_id = :reserva_id', reserva_id: 1)
  # @rooms.each { |e| 
  #   e.status = 3
  #   e.save
  # }
   # @hotel_rooms_disponibles =  @reservas_hotel_rooms
   # @reservas = Reserva.find(@rooms_a)
    # @users = request.subdomains
    # @respons = Public.users.find_by(reservation_code: e['reservation_code'])
     # @users = User.find_by(subdomain: request.subdomains)
    # amarcar = Array.new(2)
   
    # amarcar[0] = 1562593369
    # amarcar[1] = 1562593350

    # wired.mark_bookings(amarcar)
    # dateActual = Date.new(2019,10,25)
    # nombreDias=['Domingo','Lunes','Martes','Miercoles','Jueves','Viernes','Sabado']
    # @habitaciones = Hash.new  
    # @fechas = Array.new
    # mesActual = dateActual.mon 
    # cmes = ""
   
    # for i in 0..10 do
    #   nombreDiaActual = nombreDias[dateActual.wday]
    #   if  mesActual != dateActual.mon
    #     cmes = "/#{dateActual.mon.to_s}"
    #     if dateActual.wday == 0
    #       nombreDiaActual = 'Dom.'
    #     end
    #   end
    #   @fechas[i] = "#{nombreDiaActual} #{dateActual.day.to_s}#{cmes}"
    #   dateActual = dateActual + 1
    # end
    # @habitaciones['203'] = [[1,'J.Martinez',1,100],[],[1,'CIEMSA',1,102],[1,'Jorge M',1,107],[2,'Fernando',1,108],[],[3,'Chispa',1,106],[],[],[],[]]
    # @habitaciones['205'] = [[2,'Marcelo',1,101],[1,'A.Martinez12',1,103,'channels_booking.bmp'],[],[],[],[1,'Augusto',1,104],[],[],[],[],[]]
    # @habitaciones['215'] = [[3,'R.Hackenbruch123',1,100],[],[1,'COMEPA',2,105],[],[],[],[],[],[],[]]
    # @matGrid = [[1,203,10111010000],[2,205,11000100000],[1,215,10110000000]]
    celCount = 11
    dateInicio = Date.new(2019,9,5)
    # dateToday = Date.today
    dateToday = dateInicio
    dateFin = dateInicio + celCount - 1
    reservas =  Reserva
      .select('type_rooms.id_room, hotel_rooms.nro_habitacion, rooms.occupancy, reservas.reservation_code, reservas.customer_name,
              reservas.customer_surname, reservas.date_arrival, reservas.date_departure')
      .joins(rooms: [hotel_room: :type_room])
       .where('((reservas.date_arrival >= :dateInicio AND  reservas.date_arrival <= :dateFin) OR 
      (reservas.date_departure >= :dateInicio AND reservas.date_departure <= :dateFin) OR 
      (reservas.date_arrival < :dateInicio AND  reservas.date_departure >= :dateFin))',{dateInicio: dateInicio, dateFin: dateFin})
      .order( "type_rooms.id_room asc, hotel_rooms.nro_habitacion asc, reservas.date_arrival asc")
     dateActual = dateInicio
     nro_habitacion_act = ""
     @habitaciones = Hash.new {Array.new}
     reservas.each {|e|
      cantCel = e.date_departure - e.date_arrival  
      if e.nro_habitacion != nro_habitacion_act 
        nro_habitacion_act = e.nro_habitacion
        dateActual = dateInicio
      end 

      while e.date_arrival > dateActual do
        if @habitaciones[e.nro_habitacion].length == 0
          @habitaciones[e.nro_habitacion] = [[]]
        else
          @habitaciones[e.nro_habitacion] << [] 
        end 
        dateActual = dateActual + 1
      end
      if @habitaciones[e.nro_habitacion].length == 0
         @habitaciones[e.nro_habitacion] = [e.occupancy,"#{e.customer_name[0]}.#{e.customer_surname[0,10]}",cantCel,e.reservation_code] 
      else
         @habitaciones[e.nro_habitacion] << [e.occupancy,"#{e.customer_name[0]}.#{e.customer_surname[0,10]}",cantCel,e.reservation_code] 
      end 
      dateActual = dateActual + cantCel
    }


  end

end
