class TypeRoomsController < ApplicationController
  before_action :set_type_room, only: [:show, :edit, :update, :destroy]

  # GET /type_rooms
  # GET /type_rooms.json
  def index
    # @type_rooms = TypeRoom.all
    @type_rooms  = TypeRoom.find_by(id_room:  142495)
  end

  # GET /type_rooms/1
  # GET /type_rooms/1.json
  def show
  end

  # GET /type_rooms/new
  def new
    @type_room = TypeRoom.new
  end

  # GET /type_rooms/1/edit
  def edit
  end

  # POST /type_rooms
  # POST /type_rooms.json
  def create
    @type_room = TypeRoom.new(type_room_params)

    respond_to do |format|
      if @type_room.save
        format.html { redirect_to @type_room, notice: 'Type room was successfully created.' }
        format.json { render :show, status: :created, location: @type_room }
      else
        format.html { render :new }
        format.json { render json: @type_room.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /type_rooms/1
  # PATCH/PUT /type_rooms/1.json
  def update
    respond_to do |format|
      if @type_room.update(type_room_params)
        format.html { redirect_to @type_room, notice: 'Type room was successfully updated.' }
        format.json { render :show, status: :ok, location: @type_room }
      else
        format.html { render :edit }
        format.json { render json: @type_room.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /type_rooms/1
  # DELETE /type_rooms/1.json
  def destroy
    @type_room.destroy
    respond_to do |format|
      format.html { redirect_to type_rooms_url, notice: 'Type room was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_type_room
      @type_room = TypeRoom.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def type_room_params
      params.require(:type_room).permit(:id_room, :denominacion, :dir_imagen_tipo, :orden_panel, :ocupacion, :precio)
    end
end
