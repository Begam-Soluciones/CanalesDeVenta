class HotelRoomsController < ApplicationController
  before_action :set_hotel_room, only: [:show, :edit, :update, :destroy]

  # GET /hotel_rooms
  # GET /hotel_rooms.json
  def index
    @type_rooms  = TypeRoom.find_by(id_room: 142495)
    @hotel_rooms = @type_rooms.hotel_rooms
      # @hotel_rooms = HotelRoom.all
  end

  # GET /hotel_rooms/1
  # GET /hotel_rooms/1.json
  def show
  end

  # GET /hotel_rooms/new
  def new
    @hotel_room = HotelRoom.new
  end

  # GET /hotel_rooms/1/edit
  def edit
  end

  # POST /hotel_rooms
  # POST /hotel_rooms.json
  def create
    @hotel_room = HotelRoom.new(hotel_room_params)

    respond_to do |format|
      if @hotel_room.save
        format.html { redirect_to @hotel_room, notice: 'Hotel room was successfully created.' }
        format.json { render :show, status: :created, location: @hotel_room }
      else
        format.html { render :new }
        format.json { render json: @hotel_room.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /hotel_rooms/1
  # PATCH/PUT /hotel_rooms/1.json
  def update
    respond_to do |format|
      if @hotel_room.update(hotel_room_params)
        format.html { redirect_to @hotel_room, notice: 'Hotel room was successfully updated.' }
        format.json { render :show, status: :ok, location: @hotel_room }
      else
        format.html { render :edit }
        format.json { render json: @hotel_room.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /hotel_rooms/1
  # DELETE /hotel_rooms/1.json
  def destroy
    @hotel_room.destroy
    respond_to do |format|
      format.html { redirect_to hotel_rooms_url, notice: 'Hotel room was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_hotel_room
      @hotel_room = HotelRoom.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def hotel_room_params
      params.require(:hotel_room).permit(:nro_habitacion, :type_room_id, :nombre_hab, :capacidad, :camas_matr, :camas_single, :camas_single_sup, :dir_imagen_hab, :observacion, :disponibilidad_id)
    end
end
