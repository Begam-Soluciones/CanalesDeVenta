module AsignaHabitacion
  def asigna_habitacion(id, date_arrival, date_departure)
      type_rooms  = TypeRoom.find_by(id_room: id)
      hotel_rooms_t = type_rooms
      .select('hotel_rooms.id')
      .hotel_rooms
      hotel_rooms = Array.new
      hotel_rooms_t.each { |e| 
       hotel_rooms << e.id
      }

      date_ingreso = date_arrival
      date_egreso = date_departure - 1
      reservas =  Reserva
          .select('hotel_rooms.id')
          .joins(rooms: [hotel_room: :type_room])
          .where('((:date_ingreso < reservas.date_arrival and reservas.date_arrival < :date_egreso) or            
          (:date_ingreso < reservas.date_departure and reservas.date_departure < :date_egreso) or
          (:date_ingreso >= reservas.date_arrival and reservas.date_departure >= :date_egreso) or
          (:date_ingreso <= reservas.date_arrival and reservas.date_departure <= :date_egreso)) and
          type_rooms.id_room = :id_room ',{date_ingreso: date_ingreso, date_egreso: date_egreso, id_room: id})
          .to_a
      reservas_hotel_rooms = Array.new
      reservas.each { |e| 
        reservas_hotel_rooms << e.id
       }
      hotel_rooms_disponibles = hotel_rooms - reservas_hotel_rooms
      hotel_rooms_disponibles = hotel_rooms_disponibles.sort
      
     
      asigna_habitacion=hotel_rooms_disponibles[0]
  end
end