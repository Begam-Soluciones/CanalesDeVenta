require 'test_helper'

class DisponibilidadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
