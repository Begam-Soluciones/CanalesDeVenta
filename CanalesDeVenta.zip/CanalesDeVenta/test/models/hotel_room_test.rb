require 'test_helper'

class HotelRoomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
