require 'test_helper'

class HotelRoomsControllerTest < ActionController::TestCase
  setup do
    @hotel_room = hotel_rooms(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:hotel_rooms)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create hotel_room" do
    assert_difference('HotelRoom.count') do
      post :create, hotel_room: { camas_matr: @hotel_room.camas_matr, camas_single: @hotel_room.camas_single, camas_single_sup: @hotel_room.camas_single_sup, capacidad: @hotel_room.capacidad, dir_imagen_hab: @hotel_room.dir_imagen_hab, disponibilidad_id: @hotel_room.disponibilidad_id, nombre_hab: @hotel_room.nombre_hab, nro_habitacion: @hotel_room.nro_habitacion, observacion: @hotel_room.observacion, type_room_id: @hotel_room.type_room_id }
    end

    assert_redirected_to hotel_room_path(assigns(:hotel_room))
  end

  test "should show hotel_room" do
    get :show, id: @hotel_room
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @hotel_room
    assert_response :success
  end

  test "should update hotel_room" do
    patch :update, id: @hotel_room, hotel_room: { camas_matr: @hotel_room.camas_matr, camas_single: @hotel_room.camas_single, camas_single_sup: @hotel_room.camas_single_sup, capacidad: @hotel_room.capacidad, dir_imagen_hab: @hotel_room.dir_imagen_hab, disponibilidad_id: @hotel_room.disponibilidad_id, nombre_hab: @hotel_room.nombre_hab, nro_habitacion: @hotel_room.nro_habitacion, observacion: @hotel_room.observacion, type_room_id: @hotel_room.type_room_id }
    assert_redirected_to hotel_room_path(assigns(:hotel_room))
  end

  test "should destroy hotel_room" do
    assert_difference('HotelRoom.count', -1) do
      delete :destroy, id: @hotel_room
    end

    assert_redirected_to hotel_rooms_path
  end
end
