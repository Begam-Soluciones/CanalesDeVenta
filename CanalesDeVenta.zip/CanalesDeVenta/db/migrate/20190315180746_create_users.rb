class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :email
      t.string :subdomain
      t.string :account_code_ch
      t.string :password_ch
      t.string :provider_key_ch
      t.integer :lcode_ch 
      
      t.timestamps null: false
    end
  end
end