class ChangeDateArrivalToDate < ActiveRecord::Migration
  
  def self.up
   	change_column :reservas, :date_arrival, 'date USING CAST(date_arrival AS date)'
  end

  def self.down
    change_column :reservas, :date_arrival, 'string USING CAST(date_arrival AS string)'
  end

  
end
