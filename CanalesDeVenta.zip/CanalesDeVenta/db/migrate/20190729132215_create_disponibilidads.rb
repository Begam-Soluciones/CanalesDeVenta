class CreateDisponibilidads < ActiveRecord::Migration
  def change
    create_table :disponibilidads do |t|
      t.string :denominacion
      t.text :dir_imagendisp
      t.string :color_disp_back
      t.string :color_disp_activo

      t.timestamps null: false
    end
  end
end
