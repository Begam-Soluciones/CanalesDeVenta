class CreateTypeRooms < ActiveRecord::Migration
  def change
    create_table :type_rooms do |t|
      t.integer :id_room
      t.string :denominacion
      t.text :dir_imagen_tipo
      t.integer :orden_panel
      t.integer :ocupacion
      t.float :precio

      t.timestamps null: false
    end
    add_index :type_rooms, :id_room, unique: true
  end
end
