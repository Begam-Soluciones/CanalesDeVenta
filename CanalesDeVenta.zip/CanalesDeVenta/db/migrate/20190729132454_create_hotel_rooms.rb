class CreateHotelRooms < ActiveRecord::Migration
  def change
    create_table :hotel_rooms do |t|
      t.string :nro_habitacion
      t.references :type_room, index: true, foreign_key: true
      t.string :nombre_hab
      t.integer :capacidad
      t.integer :camas_matr
      t.integer :camas_single
      t.integer :camas_single_sup
      t.text :dir_imagen_hab
      t.text :observacion
      t.references :disponibilidad, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
