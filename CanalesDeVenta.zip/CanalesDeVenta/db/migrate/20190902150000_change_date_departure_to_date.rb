class ChangeDateDepartureToDate < ActiveRecord::Migration
  def self.up
   	change_column :reservas, :date_departure, 'date USING CAST(date_departure AS date)'
  end

  def self.down
    change_column :reservas, :date_departure, 'string USING CAST(date_departure AS string)'
  end  
end