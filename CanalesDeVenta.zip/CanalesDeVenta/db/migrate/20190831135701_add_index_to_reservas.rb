class AddIndexToReservas < ActiveRecord::Migration
  def change
    add_index :reservas, :date_departure
    add_index :reservas, :date_arrival
  end
end
