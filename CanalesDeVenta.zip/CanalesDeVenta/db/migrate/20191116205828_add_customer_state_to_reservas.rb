class AddCustomerStateToReservas < ActiveRecord::Migration
  def change
    add_column :reservas, :customer_state, :string
  end
end
