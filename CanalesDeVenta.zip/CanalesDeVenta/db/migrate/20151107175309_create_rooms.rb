class CreateRooms < ActiveRecord::Migration
  def change
    create_table :rooms do |t|
      t.references :hotel_room, index: true, foreign_key: true
      t.references :reserva, index: true, foreign_key: true
      t.integer :occupancy
      t.integer :status

      t.timestamps

    end
    add_index :rooms, :hotel_room_id, unique: true
  end
end
